-- MySQL dump 10.13  Distrib 5.1.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: viking
-- ------------------------------------------------------
-- Server version	5.1.41-3ubuntu12.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aliases`
--

DROP TABLE IF EXISTS `aliases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aliases` (
  `sticky` int(11) DEFAULT NULL,
  `alias` varchar(128) DEFAULT NULL,
  `command` varchar(4096) DEFAULT NULL,
  `hostname` varchar(256) DEFAULT NULL,
  KEY `alias1` (`alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `calls`
--

DROP TABLE IF EXISTS `calls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calls` (
  `call_created` varchar(128) DEFAULT NULL,
  `call_created_epoch` int(11) DEFAULT NULL,
  `function` varchar(1024) DEFAULT NULL,
  `caller_cid_name` varchar(1024) DEFAULT NULL,
  `caller_cid_num` varchar(256) DEFAULT NULL,
  `caller_dest_num` varchar(256) DEFAULT NULL,
  `caller_chan_name` varchar(1024) DEFAULT NULL,
  `caller_uuid` varchar(256) DEFAULT NULL,
  `callee_cid_name` varchar(1024) DEFAULT NULL,
  `callee_cid_num` varchar(256) DEFAULT NULL,
  `callee_dest_num` varchar(256) DEFAULT NULL,
  `callee_chan_name` varchar(1024) DEFAULT NULL,
  `callee_uuid` varchar(256) DEFAULT NULL,
  `hostname` varchar(256) DEFAULT NULL,
  KEY `calls1` (`hostname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cards_def_rates`
--

DROP TABLE IF EXISTS `cards_def_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cards_def_rates` (
  `areacode` char(10) NOT NULL,
  `description` char(40) DEFAULT NULL,
  `rate` decimal(11,4) DEFAULT NULL,
  `route` char(20) DEFAULT NULL,
  PRIMARY KEY (`areacode`),
  UNIQUE KEY `areacode` (`areacode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cards_providers`
--

DROP TABLE IF EXISTS `cards_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cards_providers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(50) DEFAULT NULL,
  `address` char(255) DEFAULT NULL,
  `zip` char(5) DEFAULT NULL,
  `city` char(50) DEFAULT NULL,
  `state` char(50) DEFAULT NULL,
  `country` char(50) DEFAULT NULL,
  `phone` char(15) DEFAULT NULL,
  `fax` char(15) DEFAULT NULL,
  `contact_name` char(50) DEFAULT NULL,
  `contact_email` char(50) DEFAULT NULL,
  `sip_ip` char(25) DEFAULT NULL,
  `rtp_ip` char(19) DEFAULT NULL,
  `codec_list` char(50) DEFAULT NULL,
  `strip_digits` char(20) NOT NULL DEFAULT '',
  `out_prefix` char(15) DEFAULT NULL,
  `cost_table` char(25) DEFAULT NULL,
  `sip_username` varchar(45) DEFAULT '1234',
  `sip_pwd` varchar(45) DEFAULT '1234',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cards_rate_mobilecard`
--

DROP TABLE IF EXISTS `cards_rate_mobilecard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cards_rate_mobilecard` (
  `areacode` char(10) NOT NULL,
  `description` char(40) DEFAULT NULL,
  `rate` decimal(11,4) DEFAULT NULL,
  `route` char(20) DEFAULT NULL,
  PRIMARY KEY (`areacode`),
  UNIQUE KEY `areacode` (`areacode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cards_settings`
--

DROP TABLE IF EXISTS `cards_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cards_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_name` char(30) NOT NULL,
  `card_ani` char(15) NOT NULL,
  `card_greeting_audio_file` char(255) DEFAULT NULL,
  `card_balance_audio_file` char(255) DEFAULT NULL,
  `card_currency_audio_file` char(255) DEFAULT NULL,
  `card_currency_decimal_audio_file` char(255) DEFAULT NULL,
  `card_destination_number_audio_file` char(255) DEFAULT NULL,
  `card_dialed_wrong_number_audio_file` char(255) DEFAULT NULL,
  `card_call_duration_audio_file` char(255) DEFAULT NULL,
  `card_disconnect_audio_file` char(255) DEFAULT NULL,
  `card_invalid_pin_audio_file` char(255) DEFAULT NULL,
  `card_no_balance_audio_file` char(255) DEFAULT NULL,
  `card_no_balance_action` char(15) DEFAULT NULL,
  `card_minlen` int(11) DEFAULT NULL,
  `free_card` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `card_ani` (`card_ani`),
  UNIQUE KEY `card_ani_2` (`card_ani`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cards_table`
--

DROP TABLE IF EXISTS `cards_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cards_table` (
  `pin` varchar(10) NOT NULL,
  `batch` int(11) DEFAULT NULL,
  `card_name` char(50) NOT NULL,
  `ratetable` char(40) DEFAULT NULL,
  `init_bal` decimal(11,4) DEFAULT NULL,
  `balance` decimal(14,2) DEFAULT NULL,
  PRIMARY KEY (`pin`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cdr`
--

DROP TABLE IF EXISTS `cdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cdr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime_start` datetime DEFAULT NULL,
  `received_ip` varchar(15) DEFAULT NULL,
  `clgnum` varchar(45) DEFAULT NULL,
  `cldnum` varchar(45) DEFAULT NULL,
  `own_ip` varchar(15) DEFAULT NULL,
  `customer_company` varchar(45) DEFAULT NULL,
  `customer_symbol` varchar(15) DEFAULT NULL,
  `customer_sip_ip` varchar(15) DEFAULT NULL,
  `customer_ratetable` varchar(25) DEFAULT NULL,
  `customer_prepaid` int(11) DEFAULT NULL,
  `customer_balance` decimal(16,4) DEFAULT NULL,
  `customer_enabled` int(11) DEFAULT NULL,
  `rate_areacode` varchar(15) DEFAULT NULL,
  `rate_description` varchar(45) DEFAULT NULL,
  `rate_rate` decimal(16,4) DEFAULT NULL,
  `rate_gateway` varchar(15) DEFAULT NULL,
  `gw_symbol` varchar(15) DEFAULT NULL,
  `gw_sip_ip` varchar(15) DEFAULT NULL,
  `gw_strip_digits` varchar(45) DEFAULT NULL,
  `gw_out_prefix` varchar(45) DEFAULT NULL,
  `gw_cost_table` varchar(45) DEFAULT NULL,
  `gw_sip_username` varchar(45) DEFAULT NULL,
  `gw_sip_pwd` varchar(45) DEFAULT NULL,
  `cost_areacode` varchar(15) DEFAULT NULL,
  `cost_description` varchar(45) DEFAULT NULL,
  `cost_cost` decimal(16,4) DEFAULT NULL,
  `max_call_curation` int(11) DEFAULT NULL,
  `datetime_answer` datetime DEFAULT NULL,
  `call_result` varchar(45) DEFAULT NULL,
  `syssec` decimal(16,0) DEFAULT NULL,
  `billsec` decimal(16,0) DEFAULT NULL,
  `call_total_rate` decimal(16,4) DEFAULT NULL,
  `call_total_cost` decimal(16,4) DEFAULT NULL,
  `customer_balance_after_call` decimal(16,4) DEFAULT NULL,
  `read_codec` varchar(15) DEFAULT NULL,
  `write_codec` varchar(15) DEFAULT NULL,
  `term_cause` int(11) DEFAULT NULL,
  `bridge_hangup_cause` varchar(15) DEFAULT NULL,
  `hangup_cause` varchar(25) DEFAULT NULL,
  `hangup_cause_q850` int(11) DEFAULT NULL,
  `datetime_end` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `crono_in_symbol` (`datetime_start`,`customer_symbol`),
  KEY `crono_in_ip` (`datetime_start`,`received_ip`,`customer_symbol`)
) ENGINE=MyISAM AUTO_INCREMENT=18587 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `channels`
--

DROP TABLE IF EXISTS `channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(256) DEFAULT NULL,
  `direction` varchar(32) DEFAULT NULL,
  `created` varchar(128) DEFAULT NULL,
  `created_epoch` int(11) DEFAULT NULL,
  `name` varchar(1024) DEFAULT NULL,
  `state` varchar(64) DEFAULT NULL,
  `cid_name` varchar(1024) DEFAULT NULL,
  `cid_num` varchar(256) DEFAULT NULL,
  `ip_addr` varchar(256) DEFAULT NULL,
  `dest` varchar(1024) DEFAULT NULL,
  `application` varchar(128) DEFAULT NULL,
  `application_data` varchar(4096) DEFAULT NULL,
  `dialplan` varchar(128) DEFAULT NULL,
  `context` varchar(128) DEFAULT NULL,
  `read_codec` varchar(128) DEFAULT NULL,
  `read_rate` varchar(32) DEFAULT NULL,
  `read_bit_rate` varchar(32) DEFAULT NULL,
  `write_codec` varchar(128) DEFAULT NULL,
  `write_rate` varchar(32) DEFAULT NULL,
  `write_bit_rate` varchar(32) DEFAULT NULL,
  `secure` varchar(32) DEFAULT NULL,
  `hostname` varchar(256) DEFAULT NULL,
  `presence_id` varchar(4096) DEFAULT NULL,
  `presence_data` varchar(4096) DEFAULT NULL,
  `callstate` varchar(45) DEFAULT NULL,
  `callee_name` varchar(256) DEFAULT NULL,
  `callee_num` varchar(256) DEFAULT NULL,
  `callee_direction` varchar(256) DEFAULT NULL,
  `call_uuid` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `indice` (`uuid`,`direction`),
  KEY `channels1` (`hostname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `complete`
--

DROP TABLE IF EXISTS `complete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complete` (
  `sticky` int(11) DEFAULT NULL,
  `a1` varchar(128) DEFAULT NULL,
  `a2` varchar(128) DEFAULT NULL,
  `a3` varchar(128) DEFAULT NULL,
  `a4` varchar(128) DEFAULT NULL,
  `a5` varchar(128) DEFAULT NULL,
  `a6` varchar(128) DEFAULT NULL,
  `a7` varchar(128) DEFAULT NULL,
  `a8` varchar(128) DEFAULT NULL,
  `a9` varchar(128) DEFAULT NULL,
  `a10` varchar(128) DEFAULT NULL,
  `hostname` varchar(256) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `interfaces`
--

DROP TABLE IF EXISTS `interfaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interfaces` (
  `type` varchar(128) DEFAULT NULL,
  `name` varchar(1024) DEFAULT NULL,
  `description` varchar(4096) DEFAULT NULL,
  `ikey` varchar(1024) DEFAULT NULL,
  `filename` varchar(4096) DEFAULT NULL,
  `syntax` varchar(4096) DEFAULT NULL,
  `hostname` varchar(256) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nat`
--

DROP TABLE IF EXISTS `nat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nat` (
  `sticky` int(11) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `proto` int(11) DEFAULT NULL,
  `hostname` varchar(256) DEFAULT NULL,
  KEY `nat_map_port_proto` (`port`,`proto`,`hostname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `providers_symbol`
--

DROP TABLE IF EXISTS `providers_symbol`;
/*!50001 DROP VIEW IF EXISTS `providers_symbol`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `providers_symbol` (
  `symbol` varchar(15)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `sip_trace`
--

DROP TABLE IF EXISTS `sip_trace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sip_trace` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime DEFAULT NULL,
  `ip_src` varchar(15) DEFAULT NULL,
  `port_src` int(11) DEFAULT NULL,
  `ip_dst` varchar(15) DEFAULT NULL,
  `port_dst` int(11) DEFAULT NULL,
  `method` varchar(60) DEFAULT NULL,
  `status` varchar(25) DEFAULT NULL,
  `from_host` varchar(15) DEFAULT NULL,
  `ruri_host` varchar(45) DEFAULT NULL,
  `ruri_user` varchar(45) DEFAULT NULL,
  `call_id` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `by_ip` (`datetime`,`ip_src`,`ip_dst`,`ruri_user`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasks` (
  `task_id` int(11) DEFAULT NULL,
  `task_desc` varchar(4096) DEFAULT NULL,
  `task_group` varchar(1024) DEFAULT NULL,
  `task_sql_manager` int(11) DEFAULT NULL,
  `hostname` varchar(256) DEFAULT NULL,
  KEY `tasks1` (`hostname`,`task_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `view_cost_tables`
--

DROP TABLE IF EXISTS `view_cost_tables`;
/*!50001 DROP VIEW IF EXISTS `view_cost_tables`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_cost_tables` (
  `table_name` varchar(64)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_rate_tables`
--

DROP TABLE IF EXISTS `view_rate_tables`;
/*!50001 DROP VIEW IF EXISTS `view_rate_tables`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_rate_tables` (
  `table_name` varchar(64)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `webusers`
--

DROP TABLE IF EXISTS `webusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wholesale_app_log`
--

DROP TABLE IF EXISTS `wholesale_app_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wholesale_app_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime DEFAULT NULL,
  `in_ip` varchar(15) DEFAULT NULL,
  `context` varchar(45) DEFAULT NULL,
  `called_number` varchar(45) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `datetime_ip` (`datetime`,`in_ip`,`context`,`called_number`)
) ENGINE=MyISAM AUTO_INCREMENT=4721 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ws_cost_`
--

DROP TABLE IF EXISTS `ws_cost_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ws_cost_` (
  `areacode` char(10) NOT NULL,
  `description` char(40) DEFAULT NULL,
  `cost` decimal(11,4) DEFAULT NULL,
  PRIMARY KEY (`areacode`),
  UNIQUE KEY `areacode` (`areacode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ws_cost_China`
--

DROP TABLE IF EXISTS `ws_cost_China`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ws_cost_China` (
  `areacode` char(10) NOT NULL,
  `description` char(40) DEFAULT NULL,
  `cost` decimal(11,4) DEFAULT NULL,
  PRIMARY KEY (`areacode`),
  UNIQUE KEY `areacode` (`areacode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ws_customers`
--

DROP TABLE IF EXISTS `ws_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ws_customers` (
  `ws_customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `ws_customer_company` varchar(45) DEFAULT NULL,
  `ws_customer_symbol` varchar(10) DEFAULT NULL,
  `ws_customer_contact_name` char(50) DEFAULT NULL,
  `ws_customer_contact_email` varchar(100) DEFAULT NULL,
  `ws_customer_address` varchar(150) DEFAULT NULL,
  `ws_customer_city` varchar(45) DEFAULT NULL,
  `ws_customer_state` varchar(45) DEFAULT NULL,
  `ws_customer_country` varchar(45) DEFAULT NULL,
  `ws_customer_phone` varchar(45) DEFAULT NULL,
  `ws_customer_fax` varchar(45) DEFAULT NULL,
  `ws_customer_zip` varchar(5) DEFAULT NULL,
  `ws_customer_sig_ip` char(15) DEFAULT NULL,
  `ws_customer_context` varchar(25) DEFAULT NULL,
  `ws_customer_ratetable` char(15) DEFAULT 'ws_def_rate',
  `ws_customer_prepaid` int(11) DEFAULT '1',
  `ws_customer_balance` decimal(11,4) DEFAULT '0.0000',
  `ws_customer_enabled` int(11) DEFAULT '0',
  `ws_customer_max_calls` int(11) NOT NULL DEFAULT '0',
  `ws_customer_billing_cycle` varchar(45) DEFAULT NULL,
  `ws_customer_send_cdr` int(11) DEFAULT NULL,
  `ws_customer_cdr_email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ws_customer_id`),
  UNIQUE KEY `sig_ip` (`ws_customer_sig_ip`,`ws_customer_context`,`ws_customer_symbol`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ws_def_costs`
--

DROP TABLE IF EXISTS `ws_def_costs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ws_def_costs` (
  `areacode` char(10) NOT NULL,
  `description` char(40) DEFAULT NULL,
  `cost` decimal(11,4) DEFAULT NULL,
  PRIMARY KEY (`areacode`),
  UNIQUE KEY `areacode` (`areacode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ws_def_rates`
--

DROP TABLE IF EXISTS `ws_def_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ws_def_rates` (
  `areacode` char(10) NOT NULL,
  `description` char(40) DEFAULT NULL,
  `rate` decimal(11,4) DEFAULT NULL,
  `route` char(20) DEFAULT NULL,
  PRIMARY KEY (`areacode`),
  UNIQUE KEY `areacode` (`areacode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ws_providers`
--

DROP TABLE IF EXISTS `ws_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ws_providers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(50) DEFAULT NULL,
  `symbol` varchar(15) NOT NULL,
  `address` char(255) DEFAULT NULL,
  `zip` char(5) DEFAULT NULL,
  `city` char(50) DEFAULT NULL,
  `state` char(50) DEFAULT NULL,
  `country` char(50) DEFAULT NULL,
  `phone` char(15) DEFAULT NULL,
  `fax` char(15) DEFAULT NULL,
  `contact_name` char(50) DEFAULT NULL,
  `contact_email` char(50) DEFAULT NULL,
  `sip_ip` char(25) DEFAULT NULL,
  `rtp_ip` char(19) DEFAULT NULL,
  `codec_list` char(50) DEFAULT NULL,
  `strip_digits` char(20) NOT NULL DEFAULT '',
  `out_prefix` char(15) DEFAULT NULL,
  `cost_table` char(25) DEFAULT NULL,
  `sip_username` varchar(45) DEFAULT '1234',
  `sip_pwd` varchar(45) DEFAULT '1234',
  PRIMARY KEY (`id`,`symbol`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `symbol_UNIQUE` (`symbol`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ws_rate_`
--

DROP TABLE IF EXISTS `ws_rate_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ws_rate_` (
  `areacode` char(10) NOT NULL,
  `description` char(40) DEFAULT NULL,
  `cost` decimal(11,4) DEFAULT NULL,
  PRIMARY KEY (`areacode`),
  UNIQUE KEY `areacode` (`areacode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ws_rate_tmp`
--

DROP TABLE IF EXISTS `ws_rate_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ws_rate_tmp` (
  `areacode` char(10) NOT NULL,
  `description` char(40) DEFAULT NULL,
  `cost` decimal(11,4) DEFAULT NULL,
  PRIMARY KEY (`areacode`),
  UNIQUE KEY `areacode` (`areacode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ws_routes`
--

DROP TABLE IF EXISTS `ws_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ws_routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_name` varchar(15) NOT NULL,
  `route_gw_1_symbol` varchar(15) NOT NULL,
  `route_gw_1_max_chan` int(11) NOT NULL,
  `route_gw_1_weight` int(11) NOT NULL,
  `route_gw_2_symbol` varchar(45) DEFAULT NULL,
  `route_gw_2_max_chan` int(11) DEFAULT NULL,
  `route_gw_2_weight` int(11) DEFAULT NULL,
  `route_gw_3_symbol` varchar(45) DEFAULT NULL,
  `route_gw_3_max_chan` int(11) DEFAULT NULL,
  `route_gw_3_weight` int(11) DEFAULT NULL,
  `route_gw_4_symbol` varchar(45) DEFAULT NULL,
  `route_gw_4_max_chan` int(11) DEFAULT NULL,
  `route_gw_4_weight` int(11) DEFAULT NULL,
  `route_gw_5_symbol` varchar(45) DEFAULT NULL,
  `route_gw_5_max_chan` int(11) DEFAULT NULL,
  `route_gw_5_weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `route_name_UNIQUE` (`route_name`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ws_settings`
--

DROP TABLE IF EXISTS `ws_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ws_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_ip` varchar(15) NOT NULL,
  `service_port` int(11) DEFAULT NULL,
  `service_type` varchar(25) DEFAULT NULL,
  `running_trace` varchar(3) DEFAULT NULL,
  `remote_host` varchar(15) DEFAULT NULL,
  `dialed_number` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`service_ip`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Final view structure for view `providers_symbol`
--

/*!50001 DROP TABLE IF EXISTS `providers_symbol`*/;
/*!50001 DROP VIEW IF EXISTS `providers_symbol`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `providers_symbol` AS select '' AS `symbol` union select `ws_providers`.`symbol` AS `symbol` from `ws_providers` order by `symbol` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_cost_tables`
--

/*!50001 DROP TABLE IF EXISTS `view_cost_tables`*/;
/*!50001 DROP VIEW IF EXISTS `view_cost_tables`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`viking`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_cost_tables` AS select `TABLES`.`TABLE_NAME` AS `table_name` from `INFORMATION_SCHEMA`.`TABLES` where (`TABLES`.`TABLE_NAME` like 'ws_cost_%') order by `TABLES`.`TABLE_NAME` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_rate_tables`
--

/*!50001 DROP TABLE IF EXISTS `view_rate_tables`*/;
/*!50001 DROP VIEW IF EXISTS `view_rate_tables`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`viking`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_rate_tables` AS select `TABLES`.`TABLE_NAME` AS `table_name` from `INFORMATION_SCHEMA`.`TABLES` where (`TABLES`.`TABLE_NAME` like 'ws_rate_%') order by `TABLES`.`TABLE_NAME` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-07-19 22:38:56
